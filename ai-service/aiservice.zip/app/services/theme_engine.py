import re
from typing import Any

from app.config import settings
from app.services.openrouter import chat_json

HEX_COLOR_RE = re.compile(r"^#(?:[0-9a-fA-F]{3}|[0-9a-fA-F]{6})$")
FORBIDDEN_CSS_PATTERNS = [
    re.compile(r"@import", re.I),
    re.compile(r"javascript\s*:", re.I),
    re.compile(r"expression\s*\(", re.I),
    re.compile(r"url\s*\(\s*['\"]?\s*https?://", re.I),
]
ALLOWED_FONTS = {
    "geist": "var(--font-geist-sans), sans-serif",
    "inter": "Inter, sans-serif",
    "manrope": "Manrope, Avenir Next, Segoe UI, sans-serif",
    "humanist sans": "Aptos, Segoe UI, sans-serif",
    "readable sans": "Verdana, Geneva, sans-serif",
    "georgia": "Georgia, serif",
}
REQUIRED_THEME_VARS = (
    "--background",
    "--foreground",
    "--card",
    "--card-foreground",
    "--primary",
    "--primary-foreground",
    "--secondary",
    "--secondary-foreground",
    "--accent",
    "--accent-foreground",
    "--border",
    "--input",
    "--ring",
    "--font-sans",
    "--radius",
)


def _normalize_hex(value: Any, fallback: str) -> str:
    candidate = str(value or "").strip()
    if HEX_COLOR_RE.fullmatch(candidate):
        if len(candidate) == 4:
            return "#" + "".join(ch * 2 for ch in candidate[1:])
        return candidate.lower()
    return fallback


def _normalize_font_family(value: Any) -> str:
    candidate = str(value or "").strip()
    if candidate in ALLOWED_FONTS.values():
        return candidate
    normalized = candidate.lower()
    return ALLOWED_FONTS.get(normalized, ALLOWED_FONTS["geist"])


def _build_variable_scaffold(*, primary: str, secondary: str, font_family: str) -> str:
    return (
        ":root {\n"
        "  --background: #ffffff;\n"
        "  --foreground: #0f172a;\n"
        "  --card: #ffffff;\n"
        "  --card-foreground: #0f172a;\n"
        "  --popover: #ffffff;\n"
        "  --popover-foreground: #0f172a;\n"
        f"  --primary: {primary};\n"
        "  --primary-foreground: #ffffff;\n"
        f"  --secondary: {secondary};\n"
        "  --secondary-foreground: #0f172a;\n"
        "  --muted: #f8fafc;\n"
        "  --muted-foreground: #475569;\n"
        f"  --accent: {secondary};\n"
        "  --accent-foreground: #ffffff;\n"
        "  --destructive: #dc2626;\n"
        "  --destructive-foreground: #ffffff;\n"
        "  --border: rgba(15, 23, 42, 0.12);\n"
        "  --input: rgba(15, 23, 42, 0.12);\n"
        f"  --ring: {primary};\n"
        f"  --sidebar: {primary};\n"
        "  --sidebar-foreground: #ffffff;\n"
        f"  --sidebar-primary: {primary};\n"
        "  --sidebar-primary-foreground: #ffffff;\n"
        f"  --sidebar-accent: {secondary};\n"
        "  --sidebar-accent-foreground: #ffffff;\n"
        "  --sidebar-border: rgba(255, 255, 255, 0.16);\n"
        f"  --sidebar-ring: {secondary};\n"
        f"  --font-sans: {font_family};\n"
        "  --font-serif: Georgia, serif;\n"
        "  --font-mono: 'Fira Code', monospace;\n"
        "  --radius: 1rem;\n"
        "  --shadow-color: rgba(15, 23, 42, 0.18);\n"
        "  --shadow-sm: 0 10px 30px -18px var(--shadow-color);\n"
        "  --shadow-md: 0 20px 45px -24px var(--shadow-color);\n"
        "  --shadow-lg: 0 26px 60px -28px var(--shadow-color);\n"
        "}\n\n"
        ".dark {\n"
        "  --background: #08111f;\n"
        "  --foreground: #e5eefb;\n"
        "  --card: #0f172a;\n"
        "  --card-foreground: #e5eefb;\n"
        "  --popover: #0f172a;\n"
        "  --popover-foreground: #e5eefb;\n"
        f"  --primary: {primary};\n"
        "  --primary-foreground: #ffffff;\n"
        "  --secondary: #172554;\n"
        "  --secondary-foreground: #e5eefb;\n"
        "  --muted: #111c32;\n"
        "  --muted-foreground: #a5b4cc;\n"
        f"  --accent: {secondary};\n"
        "  --accent-foreground: #ffffff;\n"
        "  --destructive: #f87171;\n"
        "  --destructive-foreground: #ffffff;\n"
        "  --border: rgba(226, 232, 240, 0.14);\n"
        "  --input: rgba(226, 232, 240, 0.14);\n"
        f"  --ring: {secondary};\n"
        f"  --sidebar: {primary};\n"
        "  --sidebar-foreground: #ffffff;\n"
        f"  --sidebar-primary: {primary};\n"
        "  --sidebar-primary-foreground: #ffffff;\n"
        f"  --sidebar-accent: {secondary};\n"
        "  --sidebar-accent-foreground: #ffffff;\n"
        "  --sidebar-border: rgba(226, 232, 240, 0.12);\n"
        f"  --sidebar-ring: {secondary};\n"
        f"  --font-sans: {font_family};\n"
        "  --font-serif: Georgia, serif;\n"
        "  --font-mono: 'Fira Code', monospace;\n"
        "  --radius: 1rem;\n"
        "  --shadow-color: rgba(2, 8, 23, 0.45);\n"
        "  --shadow-sm: 0 12px 32px -18px var(--shadow-color);\n"
        "  --shadow-md: 0 20px 48px -22px var(--shadow-color);\n"
        "  --shadow-lg: 0 30px 70px -26px var(--shadow-color);\n"
        "}\n\n"
        "body {\n"
        "  background: var(--background);\n"
        "  color: var(--foreground);\n"
        "  font-family: var(--font-sans);\n"
        "}\n\n"
        "a { color: var(--primary); }\n"
        "button { border-radius: var(--radius); }\n"
        ".card, [class*='card'], [class*='panel'] {\n"
        "  background: var(--card);\n"
        "  color: var(--card-foreground);\n"
        "  border: 1px solid var(--border);\n"
        "  box-shadow: var(--shadow-sm);\n"
        "}\n\n"
    )


def _sanitize_css(css: Any, *, primary: str, secondary: str, font_family: str) -> str:
    candidate = str(css or "").strip()
    for pattern in FORBIDDEN_CSS_PATTERNS:
        if pattern.search(candidate):
            raise ValueError("Generated CSS contains forbidden external or executable content")

    if len(candidate) > 12000:
        candidate = candidate[:12000].rstrip()

    scaffold = _build_variable_scaffold(
        primary=primary,
        secondary=secondary,
        font_family=font_family,
    )
    lower_candidate = candidate.lower()
    if ":root" not in lower_candidate:
        candidate = scaffold + candidate
        lower_candidate = candidate.lower()

    if ".dark" not in lower_candidate:
        dark_start = scaffold.find(".dark")
        body_start = scaffold.find("body {")
        candidate = scaffold[dark_start:body_start] + candidate
        lower_candidate = candidate.lower()

    missing_vars = [token for token in REQUIRED_THEME_VARS if token not in candidate]
    if missing_vars:
        candidate = scaffold + candidate

    if "body {" not in candidate:
        body_start = scaffold.find("body {")
        candidate = candidate + "\n\n" + scaffold[body_start:]

    return candidate


async def generate_theme_bundle(
    *,
    api_key: str,
    organization_name: str,
    description: str,
    current_custom_css: str | None,
) -> dict[str, Any]:
    prompt = f"""You are an LMS brand designer and front-end theming assistant.

Generate a visual theme for an LMS organization.

Organization name: {organization_name}
Brand description: {description.strip()}
Existing custom CSS:
{(current_custom_css or "").strip() or "(none)"}

Return ONLY valid JSON with this exact shape:
{{
  "themeName": "short theme name",
  "summary": "1-2 sentence explanation",
  "theme": {{
    "primaryColor": "#000000",
    "secondaryColor": "#000000",
    "fontFamily": "one of the allowed font stacks"
  }},
  "customCss": "raw CSS string"
}}

Allowed fontFamily values:
- var(--font-geist-sans), sans-serif
- Inter, sans-serif
- Manrope, Avenir Next, Segoe UI, sans-serif
- Aptos, Segoe UI, sans-serif
- Verdana, Geneva, sans-serif
- Georgia, serif

Strict requirements:
- Build the CSS for a modern LMS website, not a generic landing page
- The CSS MUST follow a token-based structure like this:
  1. a :root block with many CSS variables
  2. a .dark block overriding the same variables
  3. normal CSS rules that consume those variables
- Include variables such as --background, --foreground, --card, --card-foreground, --primary, --primary-foreground, --secondary, --secondary-foreground, --accent, --accent-foreground, --border, --input, --ring, --font-sans, --radius, and shadow variables
- Use the colors consistently for buttons, links, cards, hero, navigation, and accents
- Keep CSS self-contained
- Do not use @import
- Do not use @theme, @custom-variant, @apply, or any Tailwind directives
- Do not use external URLs
- Do not use javascript:, expression(), or remote assets
- Use selectors that are broad enough to affect the organization site, such as body, header, nav, main, footer, section, button, a, input, textarea, card-like containers
- Keep the CSS elegant and production-safe
- Ensure readable contrast
- Prefer gradients, subtle shadows, and polished spacing
- The customCss value must be plain CSS only, no markdown fences"""

    payload = await chat_json(
        api_key=api_key,
        model=settings.openrouter_model,
        prompt=prompt,
        temperature=0.45,
        max_tokens=2600,
    )

    raw_theme = payload.get("theme") if isinstance(payload.get("theme"), dict) else {}
    primary = _normalize_hex(raw_theme.get("primaryColor"), "#2563eb")
    secondary = _normalize_hex(raw_theme.get("secondaryColor"), "#f97316")
    font_family = _normalize_font_family(raw_theme.get("fontFamily"))
    custom_css = _sanitize_css(
        payload.get("customCss"),
        primary=primary,
        secondary=secondary,
        font_family=font_family,
    )

    return {
        "themeName": str(payload.get("themeName") or "AI Theme").strip()[:80],
        "summary": str(payload.get("summary") or "AI-generated theme").strip()[:280],
        "theme": {
            "primaryColor": primary,
            "secondaryColor": secondary,
            "fontFamily": font_family,
        },
        "customCss": custom_css,
    }
